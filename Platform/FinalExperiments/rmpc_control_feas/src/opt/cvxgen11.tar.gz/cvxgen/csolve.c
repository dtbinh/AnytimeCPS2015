/* Produced by CVXGEN, 2015-05-07 02:19:45 -0400.  */
/* CVXGEN is Copyright (C) 2006-2012 Jacob Mattingley, jem@cvxgen.com. */
/* The code in this file is Copyright (C) 2006-2012 Jacob Mattingley. */
/* CVXGEN, or solvers produced by CVXGEN, cannot be used for commercial */
/* applications without prior written permission from Jacob Mattingley. */

/* Filename: csolve.c. */
/* Description: mex-able file for running cvxgen solver. */
#include "mex.h"
#include "solver.h"
Vars vars;
Params params;
Workspace work;
Settings settings;
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
  int i, j;
  mxArray *xm, *cell, *xm_cell;
  double *src;
  double *dest;
  double *dest_cell;
  int valid_vars;
  int steps;
  int this_var_errors;
  int warned_diags;
  int prepare_for_c = 0;
  int extra_solves;
  const char *status_names[] = {"optval", "gap", "steps", "converged"};
  mwSize dims1x1of1[1] = {1};
  mwSize dims[1];
  const char *var_names[] = {"u_0", "u_1", "u_2", "u_3", "u_4", "u_5", "u_6", "u_7", "u_8", "u_9", "u_10", "z_0", "z_1", "z_2", "z_3", "z_4", "z_5", "z_6", "z_7", "z_8", "z_9", "z_10", "z_11", "u", "z"};
  const int num_var_names = 25;
  /* Avoid compiler warnings of unused variables by using a dummy assignment. */
  warned_diags = j = 0;
  extra_solves = 0;
  set_defaults();
  /* Check we got the right number of arguments. */
  if (nrhs == 0)
    mexErrMsgTxt("Not enough arguments: You need to specify at least the parameters.\n");
  if (nrhs > 1) {
    /* Assume that the second argument is the settings. */
    if (mxGetField(prhs[1], 0, "eps") != NULL)
      settings.eps = *mxGetPr(mxGetField(prhs[1], 0, "eps"));
    if (mxGetField(prhs[1], 0, "max_iters") != NULL)
      settings.max_iters = *mxGetPr(mxGetField(prhs[1], 0, "max_iters"));
    if (mxGetField(prhs[1], 0, "refine_steps") != NULL)
      settings.refine_steps = *mxGetPr(mxGetField(prhs[1], 0, "refine_steps"));
    if (mxGetField(prhs[1], 0, "verbose") != NULL)
      settings.verbose = *mxGetPr(mxGetField(prhs[1], 0, "verbose"));
    if (mxGetField(prhs[1], 0, "better_start") != NULL)
      settings.better_start = *mxGetPr(mxGetField(prhs[1], 0, "better_start"));
    if (mxGetField(prhs[1], 0, "verbose_refinement") != NULL)
      settings.verbose_refinement = *mxGetPr(mxGetField(prhs[1], 0,
            "verbose_refinement"));
    if (mxGetField(prhs[1], 0, "debug") != NULL)
      settings.debug = *mxGetPr(mxGetField(prhs[1], 0, "debug"));
    if (mxGetField(prhs[1], 0, "kkt_reg") != NULL)
      settings.kkt_reg = *mxGetPr(mxGetField(prhs[1], 0, "kkt_reg"));
    if (mxGetField(prhs[1], 0, "s_init") != NULL)
      settings.s_init = *mxGetPr(mxGetField(prhs[1], 0, "s_init"));
    if (mxGetField(prhs[1], 0, "z_init") != NULL)
      settings.z_init = *mxGetPr(mxGetField(prhs[1], 0, "z_init"));
    if (mxGetField(prhs[1], 0, "resid_tol") != NULL)
      settings.resid_tol = *mxGetPr(mxGetField(prhs[1], 0, "resid_tol"));
    if (mxGetField(prhs[1], 0, "extra_solves") != NULL)
      extra_solves = *mxGetPr(mxGetField(prhs[1], 0, "extra_solves"));
    else
      extra_solves = 0;
    if (mxGetField(prhs[1], 0, "prepare_for_c") != NULL)
      prepare_for_c = *mxGetPr(mxGetField(prhs[1], 0, "prepare_for_c"));
  }
  valid_vars = 0;
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "A");
  if (xm == NULL) {
    printf("could not find params.A.\n");
  } else {
    if (!((mxGetM(xm) == 9) && (mxGetN(xm) == 9))) {
      printf("A must be size (9,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter A must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter A must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter A must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.A;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[27];  /* (1,4) entry. */
      dest[2] = src[54];  /* (1,7) entry. */
      dest[3] = src[10];  /* (2,2) entry. */
      dest[4] = src[37];  /* (2,5) entry. */
      dest[5] = src[64];  /* (2,8) entry. */
      dest[6] = src[20];  /* (3,3) entry. */
      dest[7] = src[47];  /* (3,6) entry. */
      dest[8] = src[74];  /* (3,9) entry. */
      dest[9] = src[30];  /* (4,4) entry. */
      dest[10] = src[57];  /* (4,7) entry. */
      dest[11] = src[40];  /* (5,5) entry. */
      dest[12] = src[67];  /* (5,8) entry. */
      dest[13] = src[50];  /* (6,6) entry. */
      dest[14] = src[77];  /* (6,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "A_0");
  if (xm == NULL) {
    printf("could not find params.A_0.\n");
  } else {
    if (!((mxGetM(xm) == 9) && (mxGetN(xm) == 9))) {
      printf("A_0 must be size (9,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter A_0 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter A_0 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter A_0 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.A_0;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[27];  /* (1,4) entry. */
      dest[2] = src[54];  /* (1,7) entry. */
      dest[3] = src[10];  /* (2,2) entry. */
      dest[4] = src[37];  /* (2,5) entry. */
      dest[5] = src[64];  /* (2,8) entry. */
      dest[6] = src[20];  /* (3,3) entry. */
      dest[7] = src[47];  /* (3,6) entry. */
      dest[8] = src[74];  /* (3,9) entry. */
      dest[9] = src[30];  /* (4,4) entry. */
      dest[10] = src[57];  /* (4,7) entry. */
      dest[11] = src[40];  /* (5,5) entry. */
      dest[12] = src[67];  /* (5,8) entry. */
      dest[13] = src[50];  /* (6,6) entry. */
      dest[14] = src[77];  /* (6,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "B");
  if (xm == NULL) {
    printf("could not find params.B.\n");
  } else {
    if (!((mxGetM(xm) == 9) && (mxGetN(xm) == 3))) {
      printf("B must be size (9,3), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter B must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter B must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter B must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.B;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[10];  /* (2,2) entry. */
      dest[2] = src[20];  /* (3,3) entry. */
      dest[3] = src[3];  /* (4,1) entry. */
      dest[4] = src[13];  /* (5,2) entry. */
      dest[5] = src[23];  /* (6,3) entry. */
      dest[6] = src[6];  /* (7,1) entry. */
      dest[7] = src[16];  /* (8,2) entry. */
      dest[8] = src[26];  /* (9,3) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "B_0");
  if (xm == NULL) {
    printf("could not find params.B_0.\n");
  } else {
    if (!((mxGetM(xm) == 9) && (mxGetN(xm) == 3))) {
      printf("B_0 must be size (9,3), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter B_0 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter B_0 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter B_0 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.B_0;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[10];  /* (2,2) entry. */
      dest[2] = src[20];  /* (3,3) entry. */
      dest[3] = src[3];  /* (4,1) entry. */
      dest[4] = src[13];  /* (5,2) entry. */
      dest[5] = src[23];  /* (6,3) entry. */
      dest[6] = src[6];  /* (7,1) entry. */
      dest[7] = src[16];  /* (8,2) entry. */
      dest[8] = src[26];  /* (9,3) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_0");
  if (xm == NULL) {
    printf("could not find params.H_0.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_0 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_0 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_0 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_0 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_0;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_1");
  if (xm == NULL) {
    printf("could not find params.H_1.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_1 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_1 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_1 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_1 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_1;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_2");
  if (xm == NULL) {
    printf("could not find params.H_2.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_2 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_2 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_2 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_2 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_2;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_3");
  if (xm == NULL) {
    printf("could not find params.H_3.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_3 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_3 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_3 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_3 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_3;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_4");
  if (xm == NULL) {
    printf("could not find params.H_4.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_4 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_4 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_4 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_4 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_4;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_5");
  if (xm == NULL) {
    printf("could not find params.H_5.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_5 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_5 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_5 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_5 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_5;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_6");
  if (xm == NULL) {
    printf("could not find params.H_6.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_6 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_6 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_6 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_6 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_6;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_7");
  if (xm == NULL) {
    printf("could not find params.H_7.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_7 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_7 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_7 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_7 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_7;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_8");
  if (xm == NULL) {
    printf("could not find params.H_8.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_8 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_8 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_8 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_8 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_8;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_9");
  if (xm == NULL) {
    printf("could not find params.H_9.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_9 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_9 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_9 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_9 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_9;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "H_10");
  if (xm == NULL) {
    printf("could not find params.H_10.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("H_10 must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter H_10 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter H_10 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter H_10 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.H_10;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "Hf");
  if (xm == NULL) {
    printf("could not find params.Hf.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 9))) {
      printf("Hf must be size (18,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter Hf must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter Hf must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter Hf must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.Hf;
      src = mxGetPr(xm);
      dest[0] = src[0];  /* (1,1) entry. */
      dest[1] = src[6];  /* (7,1) entry. */
      dest[2] = src[19];  /* (2,2) entry. */
      dest[3] = src[25];  /* (8,2) entry. */
      dest[4] = src[38];  /* (3,3) entry. */
      dest[5] = src[44];  /* (9,3) entry. */
      dest[6] = src[57];  /* (4,4) entry. */
      dest[7] = src[63];  /* (10,4) entry. */
      dest[8] = src[76];  /* (5,5) entry. */
      dest[9] = src[82];  /* (11,5) entry. */
      dest[10] = src[95];  /* (6,6) entry. */
      dest[11] = src[101];  /* (12,6) entry. */
      dest[12] = src[120];  /* (13,7) entry. */
      dest[13] = src[123];  /* (16,7) entry. */
      dest[14] = src[139];  /* (14,8) entry. */
      dest[15] = src[142];  /* (17,8) entry. */
      dest[16] = src[158];  /* (15,9) entry. */
      dest[17] = src[161];  /* (18,9) entry. */
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "Q");
  if (xm == NULL) {
    printf("could not find params.Q.\n");
  } else {
    if (!((mxGetM(xm) == 9) && (mxGetN(xm) == 9))) {
      printf("Q must be size (9,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter Q must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter Q must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter Q must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.Q;
      src = mxGetPr(xm);
      for (i = 0; i < 81; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "Q_final");
  if (xm == NULL) {
    printf("could not find params.Q_final.\n");
  } else {
    if (!((mxGetM(xm) == 9) && (mxGetN(xm) == 9))) {
      printf("Q_final must be size (9,9), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter Q_final must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter Q_final must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter Q_final must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.Q_final;
      src = mxGetPr(xm);
      for (i = 0; i < 81; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_0");
  if (xm == NULL) {
    printf("could not find params.g_0.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_0 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_0 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_0 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_0 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_0;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_1");
  if (xm == NULL) {
    /* Attempt to pull g_1 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 0);
  }
  if (xm == NULL) {
    printf("could not find params.g_1 or params.g{1}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_1 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_1 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_1 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_1 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_1;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_2");
  if (xm == NULL) {
    /* Attempt to pull g_2 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 1);
  }
  if (xm == NULL) {
    printf("could not find params.g_2 or params.g{2}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_2 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_2 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_2 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_2 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_2;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_3");
  if (xm == NULL) {
    /* Attempt to pull g_3 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 2);
  }
  if (xm == NULL) {
    printf("could not find params.g_3 or params.g{3}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_3 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_3 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_3 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_3 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_3;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_4");
  if (xm == NULL) {
    /* Attempt to pull g_4 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 3);
  }
  if (xm == NULL) {
    printf("could not find params.g_4 or params.g{4}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_4 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_4 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_4 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_4 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_4;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_5");
  if (xm == NULL) {
    /* Attempt to pull g_5 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 4);
  }
  if (xm == NULL) {
    printf("could not find params.g_5 or params.g{5}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_5 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_5 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_5 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_5 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_5;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_6");
  if (xm == NULL) {
    /* Attempt to pull g_6 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 5);
  }
  if (xm == NULL) {
    printf("could not find params.g_6 or params.g{6}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_6 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_6 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_6 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_6 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_6;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_7");
  if (xm == NULL) {
    /* Attempt to pull g_7 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 6);
  }
  if (xm == NULL) {
    printf("could not find params.g_7 or params.g{7}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_7 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_7 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_7 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_7 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_7;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_8");
  if (xm == NULL) {
    /* Attempt to pull g_8 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 7);
  }
  if (xm == NULL) {
    printf("could not find params.g_8 or params.g{8}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_8 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_8 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_8 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_8 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_8;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_9");
  if (xm == NULL) {
    /* Attempt to pull g_9 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 8);
  }
  if (xm == NULL) {
    printf("could not find params.g_9 or params.g{9}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_9 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_9 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_9 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_9 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_9;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "g_10");
  if (xm == NULL) {
    /* Attempt to pull g_10 from a cell array, as an additional option. */
    cell = mxGetField(prhs[0], 0, "g");
    if (cell != NULL)
      xm = mxGetCell(cell, 9);
  }
  if (xm == NULL) {
    printf("could not find params.g_10 or params.g{10}.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("g_10 must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter g_10 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter g_10 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter g_10 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.g_10;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "gf");
  if (xm == NULL) {
    printf("could not find params.gf.\n");
  } else {
    if (!((mxGetM(xm) == 18) && (mxGetN(xm) == 1))) {
      printf("gf must be size (18,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter gf must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter gf must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter gf must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.gf;
      src = mxGetPr(xm);
      for (i = 0; i < 18; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "z_0");
  if (xm == NULL) {
    printf("could not find params.z_0.\n");
  } else {
    if (!((mxGetM(xm) == 9) && (mxGetN(xm) == 1))) {
      printf("z_0 must be size (9,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter z_0 must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter z_0 must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter z_0 must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.z_0;
      src = mxGetPr(xm);
      for (i = 0; i < 9; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  this_var_errors = 0;
  xm = mxGetField(prhs[0], 0, "z_ref");
  if (xm == NULL) {
    printf("could not find params.z_ref.\n");
  } else {
    if (!((mxGetM(xm) == 9) && (mxGetN(xm) == 1))) {
      printf("z_ref must be size (9,1), not (%d,%d).\n", mxGetM(xm), mxGetN(xm));
      this_var_errors++;
    }
    if (mxIsComplex(xm)) {
      printf("parameter z_ref must be real.\n");
      this_var_errors++;
    }
    if (!mxIsClass(xm, "double")) {
      printf("parameter z_ref must be a full matrix of doubles.\n");
      this_var_errors++;
    }
    if (mxIsSparse(xm)) {
      printf("parameter z_ref must be a full matrix.\n");
      this_var_errors++;
    }
    if (this_var_errors == 0) {
      dest = params.z_ref;
      src = mxGetPr(xm);
      for (i = 0; i < 9; i++)
        *dest++ = *src++;
      valid_vars++;
    }
  }
  if (valid_vars != 32) {
    printf("Error: %d parameters are invalid.\n", 32 - valid_vars);
    mexErrMsgTxt("invalid parameters found.");
  }
  if (prepare_for_c) {
    printf("settings.prepare_for_c == 1. thus, outputting for C.\n");
    for (i = 0; i < 9; i++)
      printf("  params.z_ref[%d] = %.6g;\n", i, params.z_ref[i]);
    for (i = 0; i < 81; i++)
      printf("  params.Q[%d] = %.6g;\n", i, params.Q[i]);
    for (i = 0; i < 81; i++)
      printf("  params.Q_final[%d] = %.6g;\n", i, params.Q_final[i]);
    for (i = 0; i < 9; i++)
      printf("  params.z_0[%d] = %.6g;\n", i, params.z_0[i]);
    for (i = 0; i < 15; i++)
      printf("  params.A_0[%d] = %.6g;\n", i, params.A_0[i]);
    for (i = 0; i < 9; i++)
      printf("  params.B_0[%d] = %.6g;\n", i, params.B_0[i]);
    for (i = 0; i < 15; i++)
      printf("  params.A[%d] = %.6g;\n", i, params.A[i]);
    for (i = 0; i < 9; i++)
      printf("  params.B[%d] = %.6g;\n", i, params.B[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_0[%d] = %.6g;\n", i, params.H_0[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_0[%d] = %.6g;\n", i, params.g_0[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_1[%d] = %.6g;\n", i, params.H_1[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_1[%d] = %.6g;\n", i, params.g_1[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_2[%d] = %.6g;\n", i, params.H_2[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_2[%d] = %.6g;\n", i, params.g_2[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_3[%d] = %.6g;\n", i, params.H_3[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_3[%d] = %.6g;\n", i, params.g_3[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_4[%d] = %.6g;\n", i, params.H_4[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_4[%d] = %.6g;\n", i, params.g_4[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_5[%d] = %.6g;\n", i, params.H_5[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_5[%d] = %.6g;\n", i, params.g_5[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_6[%d] = %.6g;\n", i, params.H_6[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_6[%d] = %.6g;\n", i, params.g_6[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_7[%d] = %.6g;\n", i, params.H_7[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_7[%d] = %.6g;\n", i, params.g_7[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_8[%d] = %.6g;\n", i, params.H_8[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_8[%d] = %.6g;\n", i, params.g_8[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_9[%d] = %.6g;\n", i, params.H_9[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_9[%d] = %.6g;\n", i, params.g_9[i]);
    for (i = 0; i < 18; i++)
      printf("  params.H_10[%d] = %.6g;\n", i, params.H_10[i]);
    for (i = 0; i < 18; i++)
      printf("  params.g_10[%d] = %.6g;\n", i, params.g_10[i]);
    for (i = 0; i < 18; i++)
      printf("  params.Hf[%d] = %.6g;\n", i, params.Hf[i]);
    for (i = 0; i < 18; i++)
      printf("  params.gf[%d] = %.6g;\n", i, params.gf[i]);
  }
  /* Perform the actual solve in here. */
  steps = solve();
  /* For profiling purposes, allow extra silent solves if desired. */
  settings.verbose = 0;
  for (i = 0; i < extra_solves; i++)
    solve();
  /* Update the status variables. */
  plhs[1] = mxCreateStructArray(1, dims1x1of1, 4, status_names);
  xm = mxCreateDoubleMatrix(1, 1, mxREAL);
  mxSetField(plhs[1], 0, "optval", xm);
  *mxGetPr(xm) = work.optval;
  xm = mxCreateDoubleMatrix(1, 1, mxREAL);
  mxSetField(plhs[1], 0, "gap", xm);
  *mxGetPr(xm) = work.gap;
  xm = mxCreateDoubleMatrix(1, 1, mxREAL);
  mxSetField(plhs[1], 0, "steps", xm);
  *mxGetPr(xm) = steps;
  xm = mxCreateDoubleMatrix(1, 1, mxREAL);
  mxSetField(plhs[1], 0, "converged", xm);
  *mxGetPr(xm) = work.converged;
  /* Extract variable values. */
  plhs[0] = mxCreateStructArray(1, dims1x1of1, num_var_names, var_names);
  /* Create cell arrays for indexed variables. */
  dims[0] = 10;
  cell = mxCreateCellArray(1, dims);
  mxSetField(plhs[0], 0, "u", cell);
  dims[0] = 11;
  cell = mxCreateCellArray(1, dims);
  mxSetField(plhs[0], 0, "z", cell);
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_0", xm);
  dest = mxGetPr(xm);
  src = vars.u_0;
  for (i = 0; i < 3; i++) {
    *dest++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_1", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 0, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_1;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_2", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 1, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_2;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_3", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 2, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_3;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_4", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 3, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_4;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_5", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 4, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_5;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_6", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 5, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_6;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_7", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 6, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_7;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_8", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 7, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_8;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_9", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 8, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_9;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(3, 1, mxREAL);
  mxSetField(plhs[0], 0, "u_10", xm);
  xm_cell = mxCreateDoubleMatrix(3, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "u");
  mxSetCell(cell, 9, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.u_10;
  for (i = 0; i < 3; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_0", xm);
  dest = mxGetPr(xm);
  src = vars.z_0;
  for (i = 0; i < 9; i++) {
    *dest++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_1", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 0, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_1;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_2", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 1, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_2;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_3", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 2, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_3;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_4", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 3, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_4;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_5", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 4, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_5;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_6", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 5, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_6;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_7", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 6, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_7;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_8", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 7, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_8;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_9", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 8, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_9;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_10", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 9, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_10;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
  xm = mxCreateDoubleMatrix(9, 1, mxREAL);
  mxSetField(plhs[0], 0, "z_11", xm);
  xm_cell = mxCreateDoubleMatrix(9, 1, mxREAL);
  cell = mxGetField(plhs[0], 0, "z");
  mxSetCell(cell, 10, xm_cell);
  dest = mxGetPr(xm);
  dest_cell = mxGetPr(xm_cell);
  src = vars.z_11;
  for (i = 0; i < 9; i++) {
    *dest++ = *src;
    *dest_cell++ = *src++;
  }
}
