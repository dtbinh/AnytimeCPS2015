% csolve  Solves a custom quadratic program very rapidly.
%
% [vars, status] = csolve(params, settings)
%
% solves the convex optimization problem
%
%   minimize(quad_form(z_0 - z_ref, Q) + quad_form(z_1 - z_ref, Q) + quad_form(z_2 - z_ref, Q) + quad_form(z_3 - z_ref, Q) + quad_form(z_4 - z_ref, Q) + quad_form(z_5 - z_ref, Q) + quad_form(z_6 - z_ref, Q) + quad_form(z_7 - z_ref, Q) + quad_form(z_8 - z_ref, Q) + quad_form(z_9 - z_ref, Q) + quad_form(z_10 - z_ref, Q) + quad_form(z_11 - z_ref, Q_final))
%   subject to
%     z_0 == z_0
%     z_1 == A_0*z_0 + B_0*u_0
%     z_1 == A*z_0 + B*u_0
%     z_2 == A*z_1 + B*u_1
%     z_3 == A*z_2 + B*u_2
%     z_4 == A*z_3 + B*u_3
%     z_5 == A*z_4 + B*u_4
%     z_6 == A*z_5 + B*u_5
%     z_7 == A*z_6 + B*u_6
%     z_8 == A*z_7 + B*u_7
%     z_9 == A*z_8 + B*u_8
%     z_10 == A*z_9 + B*u_9
%     z_11 == A*z_10 + B*u_10
%     H_0*z_0 <= g_0
%     H_1*z_1 <= g_1
%     H_2*z_2 <= g_2
%     H_3*z_3 <= g_3
%     H_4*z_4 <= g_4
%     H_5*z_5 <= g_5
%     H_6*z_6 <= g_6
%     H_7*z_7 <= g_7
%     H_8*z_8 <= g_8
%     H_9*z_9 <= g_9
%     H_10*z_10 <= g_10
%     Hf*z_11 <= gf
%
% with variables
%      u_0   3 x 1
%      u_1   3 x 1
%      u_2   3 x 1
%      u_3   3 x 1
%      u_4   3 x 1
%      u_5   3 x 1
%      u_6   3 x 1
%      u_7   3 x 1
%      u_8   3 x 1
%      u_9   3 x 1
%     u_10   3 x 1
%      z_0   9 x 1
%      z_1   9 x 1
%      z_2   9 x 1
%      z_3   9 x 1
%      z_4   9 x 1
%      z_5   9 x 1
%      z_6   9 x 1
%      z_7   9 x 1
%      z_8   9 x 1
%      z_9   9 x 1
%     z_10   9 x 1
%     z_11   9 x 1
%
% and parameters
%        A   9 x 9
%      A_0   9 x 9
%        B   9 x 3
%      B_0   9 x 3
%      H_0  18 x 9
%      H_1  18 x 9
%      H_2  18 x 9
%      H_3  18 x 9
%      H_4  18 x 9
%      H_5  18 x 9
%      H_6  18 x 9
%      H_7  18 x 9
%      H_8  18 x 9
%      H_9  18 x 9
%     H_10  18 x 9
%       Hf  18 x 9
%        Q   9 x 9    PSD
%  Q_final   9 x 9    PSD
%      g_0  18 x 1
%      g_1  18 x 1
%      g_2  18 x 1
%      g_3  18 x 1
%      g_4  18 x 1
%      g_5  18 x 1
%      g_6  18 x 1
%      g_7  18 x 1
%      g_8  18 x 1
%      g_9  18 x 1
%     g_10  18 x 1
%       gf  18 x 1
%      z_0   9 x 1
%    z_ref   9 x 1
%
% Note:
%   - Check status.converged, which will be 1 if optimization succeeded.
%   - You don't have to specify settings if you don't want to.
%   - To hide output, use settings.verbose = 0.
%   - To change iterations, use settings.max_iters = 20.
%   - You may wish to compare with cvxsolve to check the solver is correct.
%
% Specify params.A, ..., params.z_ref, then run
%   [vars, status] = csolve(params, settings)
% Produced by CVXGEN, 2015-05-07 02:19:45 -0400.
% CVXGEN is Copyright (C) 2006-2012 Jacob Mattingley, jem@cvxgen.com.
% The code in this file is Copyright (C) 2006-2012 Jacob Mattingley.
% CVXGEN, or solvers produced by CVXGEN, cannot be used for commercial
% applications without prior written permission from Jacob Mattingley.

% Filename: csolve.m.
% Description: Help file for the Matlab solver interface.
